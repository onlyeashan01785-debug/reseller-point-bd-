-- Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text not null default '',
  email text not null default '',
  role text not null default 'user' check (role in ('user','admin')),
  payment_status text not null default 'pending' check (payment_status in ('pending','approved','rejected')),
  payment_method text,
  transaction_id text,
  created_at timestamptz not null default now()
);
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null default '',
  price numeric(12,2) not null check (price > 0),
  emoji text not null default '📦',
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity integer not null check (quantity between 1 and 20),
  unit_price numeric(12,2) not null check (unit_price > 0),
  status text not null default 'pending' check (status in ('pending','processing','shipped','completed','cancelled')),
  created_at timestamptz not null default now()
);

-- Security-definer helper avoids recursive RLS checks on the profiles table.
create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin'); $$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- Create the pending profile from Auth metadata, including with email confirmation enabled.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer
set search_path = public
as $$
begin
  insert into public.profiles(id,full_name,phone,email,role,payment_status,payment_method,transaction_id)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name',''),
    coalesce(new.raw_user_meta_data->>'phone',''),
    coalesce(new.email,''),
    'user',
    'pending',
    new.raw_user_meta_data->>'payment_method',
    new.raw_user_meta_data->>'transaction_id'
  ) on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created_profile on auth.users;
create trigger on_auth_user_created_profile after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;

create policy "profile read own or admin" on public.profiles for select to authenticated
using (id=auth.uid() or public.is_admin());
-- Profile creation is handled by the trusted database trigger; no client profile inserts.
create policy "profile update admin only" on public.profiles for update to authenticated
using (public.is_admin()) with check (public.is_admin());

create policy "active products public read" on public.products for select
using (active=true or public.is_admin());
create policy "admin insert products" on public.products for insert to authenticated
with check (public.is_admin());
create policy "admin update products" on public.products for update to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "admin delete products" on public.products for delete to authenticated
using (public.is_admin());

create policy "orders read own or admin" on public.orders for select to authenticated
using (user_id=auth.uid() or public.is_admin());
create policy "approved user can create order" on public.orders for insert to authenticated
with check (user_id=auth.uid() and exists(select 1 from public.profiles me where me.id=auth.uid() and me.payment_status='approved'));
create policy "admin update orders" on public.orders for update to authenticated
using (public.is_admin()) with check (public.is_admin());

-- Create your first user through the app, then grant owner admin access.
-- Replace the email with your own account email and run this manually:
-- update public.profiles set role='admin', payment_status='approved'
-- where email='YOUR_OWNER_EMAIL';
-- Never expose the service-role key in frontend code.
