import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
export async function POST(req:Request){
 const supabase=await createClient();
 const {data:{user}}=await supabase.auth.getUser();
 if(!user) return NextResponse.redirect(new URL("/login",req.url),303);
 const {data:profile}=await supabase.from("profiles").select("payment_status").eq("id",user.id).single();
 if(profile?.payment_status!=="approved") return NextResponse.redirect(new URL("/orders?pending=1",req.url),303);
 const form=await req.formData(); const product_id=String(form.get("product_id")||""); const quantity=Number(form.get("quantity")||1);
 if(!Number.isInteger(quantity)||quantity<1||quantity>20) return NextResponse.json({error:"Invalid quantity"},{status:400});
 const {data:product}=await supabase.from("products").select("id,price,active").eq("id",product_id).single();
 if(!product||!product.active) return NextResponse.json({error:"Product unavailable"},{status:404});
 const {error}=await supabase.from("orders").insert({user_id:user.id,product_id,quantity,unit_price:product.price,status:"pending"});
 if(error) return NextResponse.json({error:"Order could not be created"},{status:400});
 return NextResponse.redirect(new URL("/orders?created=1",req.url),303);
}