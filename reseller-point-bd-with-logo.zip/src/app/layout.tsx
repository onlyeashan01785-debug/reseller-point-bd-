import type { Metadata } from "next";
import "./globals.css";
import Link from "next/link";
export const metadata: Metadata = { title: "Reseller Point BD", description: "Shop and resell with Reseller Point BD"   icons: { icon: "/icon.png", apple: "/icon.png" },
};
export default function RootLayout({children}:{children:React.ReactNode}) {
 return <html lang="bn"><body><header className="nav"><div className="navinner"><Link className="brand" href="/">🛍 Reseller Point BD</Link><nav className="links"><Link href="/products">Products</Link><Link href="/orders">My Orders</Link><Link href="/login">Login</Link><Link className="btn" href="/register">Join ৳300</Link></nav></div></header>{children}<footer className="footer">© {new Date().getFullYear()} Reseller Point BD · Secure reseller shopping</footer></body></html>
}